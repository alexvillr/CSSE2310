/*
 * testuqwordiply.c
 *      CSSE2310 - Assignment Two
 *
 *      Written by Alex Viller, a.viller@uqconnect.edu.au
 *
 * Usage:
 *  testuqwordiply [--quiet] [--parallel] testprogram jobfile
 *          optional arguments must be before program and jobfile
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <getopt.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <csse2310a3.h>

// global definitions
#define STARTER_LIST_SIZE 2
#define NUM_PIPES 4
#define READ_AND_WRITE 2
#define PROGRAM_TO_COMPARE "demo-uqwordiply"
#define ONE_OPT 1
#define TWO_OPTS 2
#define FD3 3
#define FD4 4


// enum type containing all the error codes
typedef enum {
    OK = 0,
    USAGE_ERROR = 2,
    JOBSPEC_OPEN_ERROR = 3,
    JOBSPEC_SYNTAX_ERROR = 4,
    JOBSPEC_INFILE_OPEN_ERROR = 5,
    JOBSPEC_EMPTY_ERROR = 6
} ExitStatus;

// enum type containing pipe names
typedef enum {
    STD_OUT = 0,
    STD_ERR = 1,
    FROM_TEST = 2,
    FROM_EXPECTED = 3
} PipeNames;

// enum type containing read vs write pipes
typedef enum {
    READ = 0,
    WRITE = 1
} PipeTypes;

// enum type containing all the process names
typedef enum {
    PROCESS_A = 0,
    PROCESS_B = 1,
    PROCESS_C = 2,
    PROCESS_D = 3
} Processes;

// structure type to contain all the information involving a job
typedef struct {
    int numArgs;
    char** args;
    char** testArgs;
    char* inFile;
} Job;

// structure type to hold all the jobs in one place
typedef struct {
    Job* jobs;
    int numJobs;
} JobList;

// Structure type to hold all parameters, obtained from command line
typedef struct {
    char* testPath;
    char* jobPath;
    FILE* jobFile;
    bool quiet;
    bool parallel;
    JobList jobList;
} TestParameters;

/* Funcion prototypes - see descriptions with the functions themselves */
int main(int argc, char* argv[]);
void print_usage(void);
void print_syntax_error(int, char*, char*, int);
TestParameters initialise(int argc, char* argv[]);
void opts_error_check(TestParameters params, int argc, char* originalargv[]);
JobList get_jobs(TestParameters);
void jobspec_error_check(TestParameters, JobList, char*, int);
void do_jobs(JobList, char*);
void do_job(Job, char*, int);
void run_testee(Job, char*, int[NUM_PIPES][READ_AND_WRITE]);
void run_tester(Job, int[NUM_PIPES][READ_AND_WRITE]);
void compare_std_out(Job, char*, int[NUM_PIPES][READ_AND_WRITE]);
void compare_std_err(Job, char*, int[NUM_PIPES][READ_AND_WRITE]);

/* main()
 * ------
 * The main driver for the function, pushes all content forward and ensures
 * everything is working as it should.
 */
int main(int argc, char* argv[]) {
    TestParameters params = initialise(argc, argv);
    params.jobList = get_jobs(params);
    do_jobs(params.jobList, params.testPath);
    
    for (int i = 0; i < params.jobList.numJobs; i++) {
        for (int j = 0; j < params.jobList.jobs[i].numArgs; j++) {
            free(params.jobList.jobs[i].args[j]);
            free(params.jobList.jobs[i].testArgs[j]);
        }
        free(params.jobList.jobs[i].inFile);
        free(params.jobList.jobs[i].args);
        free(params.jobList.jobs[i].testArgs);
    }
    free(params.jobList.jobs);
    fclose(params.jobFile);
    return OK;
}

/* print_usage()
 * -------------
 * This function is used to print usage to the user when incorrect command line
 * arguments are used and then exit with status 2 as found in the ExitStatus
 * type.
 */
void print_usage(void) {
    fprintf(stderr, "Usage: testuqwordiply [--quiet] [--parallel] " \
            "testprogram jobfile\n");
    exit(USAGE_ERROR);
}

/* print_syntax_error()
 * --------------------
 * This function is used to print errors to do with jobfile to the user and
 * then exits with appropriate code for the issue (see ExitStatus enum).
 * 
 * lineNum: The line the error occured on.
 *
 * jobFile: The path to the job file which has an error.
 *
 * infile: An array of strings which holds the contents of the line with the
 *      error. Gets freed.
 *
 * error: The error code to be used.
 */
void print_syntax_error(int lineNum, char* jobFile, char* infile, int error) {
    switch (error) {
        case JOBSPEC_SYNTAX_ERROR:
            fprintf(stderr, "testuqwordiply: syntax error on line %d of"\
                    " \"%s\"\n", lineNum, jobFile);
            break;
        case JOBSPEC_INFILE_OPEN_ERROR:
            fprintf(stderr, "testuqwordiply: unable to open file"\
                    " \"%s\" specified on line %d of \"%s\"\n", infile, 
                    lineNum, jobFile);
            break;
        case JOBSPEC_EMPTY_ERROR:
            fprintf(stderr, "testuqwordiply: no jobs found in \"%s\"\n", 
                    jobFile);
        default:
            break;
    }
    free(infile);
    exit(error);
}

/* initialise()
 * ------------
 * This function processes any command line arguments, checks validity, and if
 * everything is correct, returns these parameters. If anything is invalide, 
 * we print a usage error and exit.
 *
 * argc: The number of command line arguments
 *
 * argv: An array of these arguments
 *
 * Returns: 0
 * Errors: With incorrect command line arguments
 */
TestParameters initialise(int argc, char* argv[]) {
    char* originalargv[argc];
    for (int i = 0; i < argc; i++) {
        originalargv[i] = argv[i];
    }
    TestParameters params = {.testPath = NULL, .jobFile = NULL, 
        .jobPath = NULL, .parallel = false, .quiet = false};
    static struct option longOpts[] = {
        {"quiet", no_argument, NULL, 'q'},
        {"parallel", no_argument, NULL, 'p'},
        {NULL, 0, NULL, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, ":", longOpts, NULL)) != -1) {
        switch(opt) {
            case 'q':
                if (params.quiet) {
                    print_usage();
                }
                params.quiet = true;
                break;
            case 'p':
                if (params.parallel) {
                    print_usage();
                }
                params.parallel = true;
                break;
            default:
                print_usage();
        }
    }
    params.testPath = argv[optind];
    params.jobPath = argv[optind + 1];
    params.jobFile = fopen(params.jobPath, "r");

    opts_error_check(params, argc, originalargv);

    return params;
}

/*
 *
 */
void opts_error_check(TestParameters params, int argc, char* originalargv[]) {
    if (params.quiet ^ params.parallel) {
        for (int i = ONE_OPT; i < argc; i++) {
            if (originalargv[i][0] == '-') {
                print_usage();
            }
        }
    } else if (params.quiet && params.parallel) {
        for (int i = ONE_OPT; i < argc; i++) {
            if (originalargv[i][0] == '-') {
                print_usage();
            }
        }
    }

    if (argc - optind != 2) {
        print_usage();
    }
    if (params.jobFile == NULL) {
        fprintf(stderr, "testuqwordiply: Unable to open job file \"%s\"\n", \
                params.jobPath);
        exit(JOBSPEC_OPEN_ERROR);
    }
}

/* get_jobs()
 * ----------
 * This function goes through the job file and returns a list of each job. Or 
 * an error if there are any jobs which are not syntactically correct
 *
 * jobFile: The file to be searched through for jobs
 *
 * Returns: A list of jobs
 * Errors: If any jobs are syntactically incorrect
 */
JobList get_jobs(TestParameters params) {
    JobList jobs = {.numJobs = 0};
    int bufferSize = STARTER_LIST_SIZE;
    char* currentLine;
    int lineNum = 0;
    jobs.jobs = (Job*) malloc(bufferSize);
    while ((currentLine = read_line(params.jobFile))) {
        char lineArray[strlen(currentLine) + 1];
        strcpy(lineArray, currentLine);
        lineNum++;
        bool commentLine = false;
        if (currentLine[0] == '#' || currentLine[0] == '\0') {
            commentLine = true;
        }
        if (!commentLine) {
            jobspec_error_check(params, jobs, currentLine, lineNum);
            char** splitLine = split_line(lineArray, ',');
            int numArgs;
            char** args = split_space_not_quote(splitLine[1], &numArgs);
            char** mallocedArgs = (char**) malloc((numArgs + 1) * 
                    sizeof(char*));
            char** mallocedTestArgs = (char**) malloc((numArgs + 1) *
                    sizeof(char*));
            for (int i = 1; i < numArgs + 1; i++) {
                mallocedArgs[i] = strdup(args[i - 1]);
                mallocedTestArgs[i] = strdup(args[i - 1]);
            }
            char* fileName = strdup(splitLine[0]);
            mallocedArgs[0] = strdup(fileName);
            mallocedTestArgs[0] = strdup(PROGRAM_TO_COMPARE);
            Job currentJob = {.inFile = fileName, .numArgs = numArgs + 1};
            currentJob.args = mallocedArgs;
            currentJob.testArgs = mallocedTestArgs;
            bufferSize = bufferSize + sizeof(currentJob);
            jobs.jobs = (Job*) realloc(jobs.jobs, bufferSize);
            jobs.jobs[jobs.numJobs] = currentJob;
            jobs.numJobs++;
            free(splitLine);
            free(args);
        }
        free(currentLine);
    }
    if (jobs.numJobs == 0) {
        free(jobs.jobs);
        fclose(params.jobFile);
        print_syntax_error(-1, params.jobPath, (char*) malloc(1),
                JOBSPEC_EMPTY_ERROR);
    }
    return jobs;
}

/* jobspec_error_check()
 *
 */
void jobspec_error_check(TestParameters params, JobList jobs, char* line, 
        int lineNum) {
    int error = -1; // initialise no error
    char** splitLine = split_line(line, ',');
    FILE* inFile = fopen(splitLine[0], "r");
    bool noComma = splitLine[0] == NULL;
    bool validInfile = strcmp(splitLine[0], "");
    bool twoCommas = splitLine[2] == NULL;
    if (noComma || !validInfile || !twoCommas) {
        error = JOBSPEC_SYNTAX_ERROR;
    } else if (inFile == NULL) {
        error = JOBSPEC_INFILE_OPEN_ERROR;
    }
    if (error == -1) {
        fclose(inFile);
        free(splitLine);
        return;
    } else if (inFile != NULL) {
        fclose(inFile);
    }
    char* inFileName = strdup(splitLine[0]);
    fclose(params.jobFile);
    free(jobs.jobs);
    free(splitLine);
    free(line);
    print_syntax_error(lineNum, params.jobPath, inFileName, error);
}

/*
 *
 */ 
void do_jobs(JobList jobs, char* testPath) {
    for (int i = 0; i < jobs.numJobs; i++) {
        printf("Starting job %d\n", i + 1);
        fflush(stdout);
        do_job(jobs.jobs[i], testPath, (i + 1));
    }
}

/*
 *
 */
void do_job(Job job, char* testPath, int jobNum) {
    pid_t children[NUM_PIPES];
    close(FROM_TEST);
    close(FROM_EXPECTED);
    int fd3 = open("/dev/null", O_WRONLY);
    int fd4 = open("/dev/null", O_WRONLY);
    dup2(fd3, FD3);
    dup2(fd4, FD4);
    if (fd3 == -1 || fd4 == -1) {
        perror("creating file descriptors failure");
    }
    int pipes[NUM_PIPES][READ_AND_WRITE];
    for (int i = 0; i < NUM_PIPES; i++) {
        if (pipe(pipes[i]) == -1) {
            perror("Pipe creation error");
            return;
        }
    }

    // Redirect standard input to the input file
    int inputFd = open(job.inFile, O_RDONLY);
    dup2(inputFd, STDIN_FILENO);
    // make prefix
    char prefix[32];
    sprintf(prefix, "\"Job %d stdout\"", jobNum);

    for (int child = 0; child < NUM_PIPES; child++) {
        pid_t childPid = fork();
        if (childPid == -1) {
            perror("Fork failed");
            return;
        }
        if (childPid == 0) { // Children
            if (child == PROCESS_A) {
                printf("child a start\n");
                run_testee(job, testPath, pipes);
            } else if (child == PROCESS_B) {
                printf("child b start\n");
                run_tester(job, pipes);
            } else if (child == PROCESS_C) {
                for (int i = 0; i < child; i++) {
                    waitpid(children[i], NULL, 0);
                }
                printf("child c start\n");
                compare_std_out(job, prefix, pipes);
            } else if (child == PROCESS_D) {
                for (int i = 0; i < child; i++) {
                    waitpid(children[i], NULL, 0);
                }
                printf("child d start\n");
                compare_std_err(job, prefix, pipes);
            }
            return; // Should never reach here. But just in case
        } else { // Parent
            children[child] = childPid;
        }
    }

    for (int i = 0; i < NUM_PIPES; i++) {
        waitpid(children[i], NULL, 0);
        close(pipes[i][WRITE]);
        close(pipes[i][READ]);

    }

    close(inputFd);
    close(FD3);
    close(FD4);
}

/*
 *
 */
void run_testee(Job job, char* testPath, 
        int pipes[NUM_PIPES][READ_AND_WRITE]) {
    // Redirect stdout and stderr to pipes
    dup2(pipes[STD_OUT][WRITE], STDOUT_FILENO);
    dup2(pipes[STD_ERR][WRITE], STDERR_FILENO);
    // Redirect standard output and standard error to file descriptor 3
    close(pipes[STD_OUT][READ]);
    close(pipes[STD_ERR][READ]);
    close(pipes[FROM_EXPECTED][READ]);
    close(pipes[FROM_EXPECTED][WRITE]);
    close(pipes[FROM_TEST][READ]);
    if (dup2(pipes[FROM_TEST][WRITE], pipes[STD_OUT][WRITE]) == -1) {
        perror("dup2 stdout fd3");
    }
    if (dup2(pipes[FROM_TEST][WRITE], pipes[STD_ERR][WRITE]) == -1) {
        perror("dup2 stderr fd3");
    }
    close(pipes[STD_OUT][WRITE]);
    close(pipes[STD_ERR][WRITE]);
    // Execute the program being tested
    execvp(testPath, job.args);

    // If execvp returns, there was an error
    perror("Execution failed");
    return;
}

/*
 *
 */
void run_tester(Job job, int pipes[NUM_PIPES][READ_AND_WRITE]) {
    // Redirect stdout and stderr to pipes
    dup2(pipes[STD_OUT][WRITE], STDOUT_FILENO);
    dup2(pipes[STD_ERR][WRITE], STDERR_FILENO);
    // Redirect and close unnecassary pipes
    close(pipes[STD_OUT][READ]);
    close(pipes[STD_ERR][READ]);
    close(pipes[FROM_TEST][READ]);
    close(pipes[FROM_TEST][WRITE]);
    close(pipes[FROM_EXPECTED][READ]);
    if (dup2(pipes[FROM_EXPECTED][WRITE], pipes[STD_OUT][WRITE]) == -1) {
        perror("dup2 stdout fd4");
    }
    if (dup2(pipes[FROM_EXPECTED][WRITE], pipes[STD_ERR][WRITE]) == -1) {
        perror("dup2 stderr fd4");
    }
    close(pipes[STD_OUT][WRITE]);
    close(pipes[STD_ERR][WRITE]);
    // Execute the program being tested
    execvp(PROGRAM_TO_COMPARE, job.testArgs);

    // If execvp returns, there was an error
    perror("Execution failed");
    return;
}

/*
 *
 */
void compare_std_out(Job job, char* prefix,
        int pipes[NUM_PIPES][READ_AND_WRITE]) {
    // Redirect and close unnecassary pipes
    close(pipes[STD_OUT][WRITE]);
    close(pipes[STD_ERR][WRITE]);
    close(pipes[FROM_TEST][WRITE]);
    close(pipes[FROM_EXPECTED][WRITE]);
    if (dup2(FD3, pipes[FROM_TEST][READ]) == -1) {
        perror("dup2 stdout fd4");
    }
    if (dup2(FD4, pipes[FROM_EXPECTED][READ]) == -1) {
        perror("dup2 stderr fd4");
    }
    close(pipes[FROM_TEST][READ]);
    close(pipes[FROM_EXPECTED][READ]);
    

    char* compare = "uqcmp";
    char* args[] = { "uqcmp", prefix, NULL };

    execvp(compare, args);
    // If execvp returns, there was an error
    perror("Execution failed");
    return;
}

/*
 *
 */
void compare_std_err(Job job, char* prefix,
        int pipes[NUM_PIPES][READ_AND_WRITE]) {
    // Redirect and close unnecassary pipes
    close(pipes[STD_OUT][WRITE]);
    close(pipes[STD_ERR][WRITE]);
    close(pipes[FROM_TEST][WRITE]);
    close(pipes[FROM_EXPECTED][WRITE]);
    if (dup2(FD3, pipes[FROM_TEST][READ]) == -1) {
        perror("dup2 stdout fd4");
    }
    if (dup2(FD4, pipes[FROM_EXPECTED][READ]) == -1) {
        perror("dup2 stderr fd4");
    }
    close(pipes[FROM_TEST][READ]);
    close(pipes[FROM_EXPECTED][READ]);


    char* compare = "uqcmp";
    char* args[] = { "uqcmp", prefix, NULL };

    execvp(compare, args);
    // If execvp returns, there was an error
    perror("Execution failed");
    return;
}
